-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Erstellungszeit: 03. Jul 2020 um 13:40
-- Server-Version: 10.3.22-MariaDB-1:10.3.22+maria~stretch
-- PHP-Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `danielbrites1_aufgabenliste`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `aufgabe`
--

CREATE TABLE `aufgabe` (
  `id` int(11) NOT NULL,
  `titel` varchar(50) NOT NULL,
  `beschreibung` varchar(50) NOT NULL,
  `frist` date NOT NULL,
  `gewicht` int(11) NOT NULL,
  `status` enum('open','in_process','done','delayed_done','cancelled') NOT NULL DEFAULT 'open'
  `aufgabe_liste_id` int(11) UNSIGNED NOT NULL DEFAULT 0,
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `aufgabe`
--

INSERT INTO `aufgabe` (`id`, `titel`, `beschreibung`, `frist`, `gewicht`, `status`, `aufgabe_liste_id`) VALUES
(1, 'Einkaufsliste', 'Brot, Wasser, Bier', '2020-07-23', 1, 'offen', 1),
(2, 'Arzttermin', 'Impfungen auffrischen lassen', '2020-08-30', 1, 'offen', 1),
(3, 'Abendessen', 'Tisch reservieren', '2020-07-22', 1, 'offen', 2),
(4, 'Besprechung', 'Unterlagen vorbereiten', '0000-00-00', 2, 'offen', 2),
(5, 'Urlaub', 'Urlaub eintragen und bestädigen lassen', '2020-10-02', 2, 'offen', 3),
(6, 'Projekt', 'Projektplan erstellen', '2020-08-06', 1, 'offen', 3);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `aufgabenliste`
--

CREATE TABLE `aufgabenliste` (
  `id` int(11) NOT NULL,
  `titel` varchar(50) NOT NULL,
  `ersteller_id` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `aufgabenliste`
--

INSERT INTO `aufgabenliste` (`id`, `titel`, `ersteller_id`) VALUES
(1, 'Allgemein', 1),
(1, 'Allgemein', 1),
(1, 'Allgemein', 1),
(2, 'Arbeit', 2),
(2, 'Arbeit', 2),
(2, 'Arbeit', 2);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `ersteller`
--

CREATE TABLE `ersteller` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `vorname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `ersteller`
--

INSERT INTO `ersteller` (`id`, `name`, `vorname`) VALUES
(1, 'Daniel', 'Brites'),
(2, 'Max', 'Frommherz');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `aufgabe`
--
ALTER TABLE `aufgabe`
  ADD PRIMARY KEY (`id`);
  ADD KEY `index_foreignkey_aufgabe_aufgabe_liste` (`aufgabe_liste_id`);

--
-- Indizes für die Tabelle `aufgabenliste`
--
ALTER TABLE `aufgabenliste`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index_foreignkey_aufgabenliste_ersteller` (`ersteller_id`);

--
-- Indizes für die Tabelle `ersteller`
--
ALTER TABLE `ersteller`
  ADD PRIMARY KEY (`id`);
  ADD KEY `erstellerid` (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `aufgabe`
--
ALTER TABLE `aufgabe`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT für Tabelle `aufgabenliste`
--
ALTER TABLE `aufgabenliste`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT für Tabelle `ersteller`
--
ALTER TABLE `ersteller`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
