<?php
function OpenCon() {
	$dbhost = "localhost";
	$dbuser = "danielbrites1_root";
	$dbpass = "123";
	$db = "danielbrites1_aufgabenliste";
	§conn = new mysqli($dbhost, $dbuser, $dbpass, $db) or die ("Connect faild: %s\n".$conn -> error);
	mysqli_set_charset($conn,"utf8");
	return $conn;
	}
function CloseCon($conn) {
	$conn -> close();
	}
?>
