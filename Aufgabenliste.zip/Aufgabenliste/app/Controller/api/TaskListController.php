<?php declare(strict_types=1);

namespace App\Controller\api;

use App\Controller\BasicController;
use R;
use Slim\Psr7\Request;

class TaskListController extends BasicController
{

    public function all(Request $request, $response): \Slim\Psr7\Response
    {
        $aufgabenListen = R::find('aufgabenliste', 'ersteller_id = ?', [$this->getContainer()->get('ersteller')->getId()]);

        return $this->createApiResponse($response, R::exportAll($aufgabenListen));
    }

    public function allIds(Request $request, $response): \Slim\Psr7\Response
    {
        $aufgabenListen = R::find('aufgabenListe', 'ersteller_id = ?', [$this->getContainer()->get('ersteller')->getId()]);

        $result =[];
        foreach ($aufgabenListen as $aufgabenListe) {
            $result[] = $aufgabenListe->getID();
        }

        return $this->createApiResponse($response, $result);
    }

    public function aufgabenListeById(Request $request, $response): \Slim\Psr7\Response
    {
        $aufgabenListe = R::findOne('aufgabenliste', 'ersteller_id = ? AND id = ? ', [$this->getContainer()->get('ersteller')->getId(), $request->getAttribute('id')]);

        if(!$aufgabenListe) {
            return $this->createApiResponse($response, ['message' => 'Datensatz nicht gefunden'], 404);
        }

        return $this->createApiResponse($response, $aufgabenListe->export());
    }

    public function create(Request $request, $response): \Slim\Psr7\Response
    {
        $input = $request->getParsedBody();
        if(!isset($input['name']))
        {
            return $this->createApiResponse($response, ['message' => 'Nicht alle Parameter wurden gefunden,die Parameter sind : name'], 400);
        }
        $aufgabenliste = R::dispense('aufgabenliste');
        $aufgabenliste['name'] = $input['name'];
        $aufgabenliste['ersteller_id'] = 1;

        $id = R::store($aufgabenliste);

        return $this->createApiResponse($response, ['id' => $id]);
    }

    public function update(Request $request, $response): \Slim\Psr7\Response
    {
        $aufgabenListe = R::findOne('aufgabenliste', 'ersteller_id = ? AND id = ? ', [$this->getContainer()->get('ersteller')->getId(), $request->getAttribute('id')]);

        if(!$aufgabenListe) {
            return $this->createApiResponse($response, ['message' => 'Datensatz nicht gefunden'], 404);
        }
        $input = $request->getParsedBody();
        if(!isset($input['name']))
        {
            return $this->createApiResponse($response, ['message' => 'Nicht alle Parameter wurden gefunden,die Parameter sind : name'], 400);
        }

        $aufgabenListe->name = $input['name'];

        $id = R::store($aufgabenListe);

        return $this->createApiResponse($response, ['id' => $id]);
    }

    public function delete(Request $request, $response): \Slim\Psr7\Response
    {
        $aufgabenListe = R::findOne('aufgabenliste', 'ersteller_id = ? AND id = ? ', [$this->getContainer()->get('ersteller')->getId(), $request->getAttribute('id')]);

        if(!$aufgabenListe) {
            return $this->createApiResponse($response, ['message' => 'Datensatz nicht gefunden'], 404);
        }

        R::trash($aufgabenListe);

        $aufgaben = R::findMulti( 'aufgabe', '
            SELECT aufgabe.* FROM aufgabe
        INNER JOIN aufgabenliste ON aufgabe.aufgabe_liste_id = aufgabenliste.id
        WHERE aufgabe.ersteller_id = ? AND aufgabe.id = ?
    ', [ $this->getContainer()->get('ersteller')->getId(), $aufgabenListe->getID()] );

        R::trashAll($aufgaben);


        return $this->createApiResponse($response, ['id' => $request->getAttribute('id')]);
    }
}