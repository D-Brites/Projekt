<?php declare(strict_types=1);

namespace App\Controller\api;

use App\Controller\BasicController;
use R;
use Slim\Psr7\Request;

class TaskController extends BasicController
{

    public function all($request, $response): \Slim\Psr7\Response
    {
        $aufgaben = R::findMulti( 'aufgabe', '
        SELECT aufgabe.* FROM aufgabe
        INNER JOIN aufgabenliste ON aufgabe.aufgabe_liste_id = aufgabenliste.id
        WHERE aufgabenliste.ersteller_id = ?
    ', [ $this->getContainer()->get('ersteller')->getId()] );

        return $this->createApiResponse($response, R::exportAll($aufgaben['aufgabe']));
    }

    public function aufgabeByAufgabenlisteID(Request $request, $response, $args): \Slim\Psr7\Response
    {
        $aufgaben = R::findMulti( 'aufgabe', '
            SELECT aufgabe.* FROM aufgabe
        INNER JOIN aufgabenliste ON aufgabe.aufgabe_liste_id = aufgabenliste.id
        WHERE aufgabenliste.ersteller_id = ? AND aufgabenliste.id = ?
    ', [ $this->getContainer()->get('ersteller')->getId(), $args['aufgabenlisteId']] );

        return $this->createApiResponse($response, R::exportAll($aufgaben['aufgabe']));
    }

    public function create(Request $request, $response, $args): \Slim\Psr7\Response
    {
        $aufgabenListe = R::findOne('aufgabenliste', 'ersteller_id = ? AND id = ? ', [$this->getContainer()->get('ersteller')->getId(), $args['aufgabenlisteId']]);

        if(!$aufgabenListe) {
            return $this->createApiResponse($response, ['message' => 'Der Datensatz der Aufgabenliste wurde nicht gefunden.'], 404);
        }

        $input = $request->getParsedBody();
        if(!isset($input['titel'], $input['status'], $input['gewicht'], $input['beschreibung'], $input['frist']))
        {
            return $this->createApiResponse($response, ['message' => 'Nicht alle Parameter wurden gefunden,die Parameter sind : titel, status, gewicht, beschreibung, frist'], 400);
        }
        $aufgabe = R::dispense('aufgabe');
        $aufgabe['titel'] = $input['titel'];
        $aufgabe['aufgabe_liste_id'] = $aufgabenListe->getID();
        $aufgabe['status'] = $input['status'];
        $aufgabe['gewicht'] = $input['gewicht'];
        $aufgabe['beschreibung'] = $input['beschreibung'];
        $aufgabe['frist'] = $input['frist'];

        $id = R::store($aufgabe);

        return $this->createApiResponse($response, ['id' => $id]);
    }

    public function update(Request $request, $response, $args): \Slim\Psr7\Response
    {
        $aufgabenListe = R::findOne('aufgabenliste', 'ersteller_id = ? AND id = ? ', [$this->getContainer()->get('ersteller')->getId(), $args['aufgabenlisteId']]);

        if(!$aufgabenListe) {
            return $this->createApiResponse($response, ['message' => 'Der Datensatz der Aufgabenliste wurde nicht gefunden.'], 404);
        }

        $aufgabe = R::findOne( 'aufgabe', 'aufgabe_liste_id = ? AND id = ?', [ $args['aufgabenlisteId'], $request->getAttribute('id')] );

        if(!$aufgabe) {
            return $this->createApiResponse($response, ['message' => 'Datensatz nicht gefunden'], 404);
        }

        if($aufgabe->status === 'erledigt' || $aufgabe->status === 'teilweise_erledigt')
        {
            return $this->createApiResponse($response, ['message' => 'Datensatz nicht mehr veränderbar'], 403);
        }

        $input = $request->getParsedBody();
        if(!isset($input['titel'], $input['status'], $input['gewicht'], $input['beschreibung'], $input['frist']))
        {
            return $this->createApiResponse($response, ['message' => $input], 400);
        }

        $aufgabe['titel'] = $input['titel'];
        $aufgabe['status'] = $input['status'];
        $aufgabe['gewicht'] = $input['gewicht'];
        $aufgabe['beschreibung'] = $input['beschreibung'];
        $aufgabe['frist'] = $input['frist'];

        $id = R::store($aufgabe);

        return $this->createApiResponse($response, ['id' => $id]);
    }

    public function delete(Request $request, $response, $args): \Slim\Psr7\Response
    {
        $aufgabenListe = R::findOne('aufgabenliste', 'ersteller_id = ? AND id = ? ', [$this->getContainer()->get('ersteller')->getId(), $args['aufgabenlisteId']]);

        if(!$aufgabenListe) {
            return $this->createApiResponse($response, ['message' => 'Der Datensatz der Aufgabenliste wurde nicht gefunden.'], 404);
        }

        $aufgabe = R::findOne( 'aufgabe', 'aufgabe_liste_id = ? AND id = ?', [ $args['aufgabenlisteId'], $request->getAttribute('id')] );

        if(!$aufgabe) {
            return $this->createApiResponse($response, ['message' => 'Datensatz nicht gefunden'], 404);
        }

        if($aufgabe->status === 'erledigt' || $aufgabe->status === 'teilweise_erledigt')
        {
            return $this->createApiResponse($response, ['message' => 'Datensatz nicht mehr veränderbar'], 403);
        }

        R::trash($aufgabe);

        return $this->createApiResponse($response, ['id' => $request->getAttribute('id')]);
    }
}