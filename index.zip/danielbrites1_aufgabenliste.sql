-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Erstellungszeit: 01. Jul 2020 um 18:24
-- Server-Version: 10.3.22-MariaDB-1:10.3.22+maria~stretch
-- PHP-Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `danielbrites1_aufgabenliste`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Aufgabe`
--

CREATE TABLE `Aufgabe` (
  `AufgabeNR` int(11) NOT NULL,
  `Titel` varchar(50) NOT NULL,
  `Beschreibung` varchar(50) NOT NULL,
  `Frist` date NOT NULL,
  `Gewicht` int(11) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Aufgabe`
--

INSERT INTO `Aufgabe` (`AufgabeNR`, `Titel`, `Beschreibung`, `Frist`, `Gewicht`, `Status`) VALUES
(1, 'Einkaufsliste', 'Brot, Wasser, Bier', '2020-07-23', 1, 'offen'),
(2, 'Arzttermin', 'Impfungen auffrischen lassen', '2020-08-30', 1, 'offen'),
(3, 'Abendessen', 'Tisch reservieren', '2020-07-22', 1, 'offen'),
(4, 'Besprechung', 'Unterlagen vorbereiten', '0000-00-00', 2, 'offen'),
(5, 'Urlaub', 'Urlaub eintragen und bestädigen lassen', '2020-10-02', 2, 'offen'),
(6, 'Projekt', 'Projektplan erstellen', '2020-08-06', 1, 'offen');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Aufgabenliste`
--

CREATE TABLE `Aufgabenliste` (
  `AufgabenlisteNR` int(11) NOT NULL,
  `Titel` varchar(50) NOT NULL,
  `AufgabeNR` int(11) NOT NULL,
  `ErstellerNR` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Aufgabenliste`
--

INSERT INTO `Aufgabenliste` (`AufgabenlisteNR`, `Titel`, `AufgabeNR`, `ErstellerNR`) VALUES
(1, 'Allgemein', 1, 1),
(1, 'Allgemein', 2, 1),
(1, 'Allgemein', 3, 1),
(2, 'Arbeit', 4, 2),
(2, 'Arbeit', 5, 2),
(2, 'Arbeit', 6, 2);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Ersteller`
--

CREATE TABLE `Ersteller` (
  `ErstellerNR` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Vorname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Ersteller`
--

INSERT INTO `Ersteller` (`ErstellerNR`, `Name`, `Vorname`) VALUES
(1, 'Daniel', 'Brites'),
(2, 'Max', 'Frommherz');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `Aufgabe`
--
ALTER TABLE `Aufgabe`
  ADD PRIMARY KEY (`AufgabeNR`);

--
-- Indizes für die Tabelle `Aufgabenliste`
--
ALTER TABLE `Aufgabenliste`
  ADD PRIMARY KEY (`AufgabenlisteNR`,`AufgabeNR`,`ErstellerNR`);

--
-- Indizes für die Tabelle `Ersteller`
--
ALTER TABLE `Ersteller`
  ADD PRIMARY KEY (`ErstellerNR`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
