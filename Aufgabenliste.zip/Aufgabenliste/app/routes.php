<?php

use Slim\Exception\HttpNotFoundException;
use Slim\Psr7\Request;
use Slim\Psr7\Response;

$app->group('/backend', function(\Slim\Routing\RouteCollectorProxy $app) use ($container) {
    $app->get('/test', \App\Controller\LoginController::class . ':test');
    $app->post('/login', \App\Controller\LoginController::class . ':login');
    $app->group('/api', function(\Slim\Routing\RouteCollectorProxy $group) {

        $group->get('/aufgabenliste', \App\Controller\api\TaskListController::class . ':all');
        $group->get('/aufgabenlisteIds', \App\Controller\api\TaskListController::class . ':allIds');
        $group->get('/aufgabenliste/{id:[0-9]+}', \App\Controller\api\TaskListController::class . ':aufgabenlisteById');

        $group->get('/aufgaben', \App\Controller\api\TaskController::class . ':all');
        $group->group('/aufgabenliste/{aufgabenlisteId:[0-9]+}', function (\Slim\Routing\RouteCollectorProxy $group) {
            $group->get('/aufgaben', \App\Controller\api\TaskController::class . ':aufgabeByAufgabenlisteID');
            $group->post('/aufgabe', \App\Controller\api\TaskController::class . ':create');
            $group->put('/aufgabe/{id:[0-9]+}', \App\Controller\api\TaskController::class . ':update');
            $group->delete('/aufgabe/{id:[0-9]+}', \App\Controller\api\TaskController::class . ':delete');
        });
        $group->post('/aufgabenliste', \App\Controller\api\TaskListController::class . ':create');
        $group->put('/aufgabenliste/{id:[0-9]+}', \App\Controller\api\TaskListController::class . ':update');
        $group->delete('/aufgabenliste/{id:[0-9]+}', \App\Controller\api\TaskListController::class . ':delete');
        $group->options('/api/{routes:.+}', function ($request, $response, $args) {
            return $response;
        });
        $group->map(['GET', 'POST', 'PUT', 'DELETE', 'PATCH'], '/api/{routes:.+}', function ($request, $response) {
            throw new HttpNotFoundException($request);
        });
    })->addMiddleware(new \App\Middleware\UserMiddleware($container))->addMiddleware(new \App\Middleware\CorsMiddleware());

    $app->options('/api/{routes:.+}', function ($request, $response, $args) {
        return $response;
    });

    $app->map(['GET', 'POST', 'PUT', 'DELETE', 'PATCH'], '/api/{routes:.+}', function ($request, $response) {
        throw new HttpNotFoundException($request);
    });
});
$app->add(function ($request, $handler) {
    $response = $handler->handle($request);
    return $response
        ->withHeader('Access-Control-Allow-Origin', '*')
        ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization, Access-Control-Allow-Origin')
        ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
});