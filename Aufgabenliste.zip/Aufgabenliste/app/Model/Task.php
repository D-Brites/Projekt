<?php

namespace App\Model;

/**
 * Class Task
 * @package App\Model
 */
class Task extends \RedBean_SimpleModel
{

}