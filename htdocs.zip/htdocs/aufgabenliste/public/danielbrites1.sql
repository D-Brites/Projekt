-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Erstellungszeit: 26. Jun 2020 um 12:56
-- Server-Version: 10.3.22-MariaDB-1:10.3.22+maria~stretch
-- PHP-Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `danielbrites1`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Aufgabe`
--

CREATE TABLE `Aufgabe` (
  `AufgabeNR` int(11) NOT NULL,
  `Titel` varchar(50) NOT NULL,
  `Beschreibung` varchar(50) NOT NULL,
  `Gewicht` int(11) NOT NULL,
  `Frist` date NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Aufgabe`
--

INSERT INTO `Aufgabe` (`AufgabeNR`, `Titel`, `Beschreibung`, `Gewicht`, `Frist`, `Status`) VALUES
(1, 'Einkauf', 'EInkaufsliste', 3, '0000-00-00', 'offen');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Aufgabenliste`
--

CREATE TABLE `Aufgabenliste` (
  `AufgabenlisteNR` int(11) NOT NULL,
  `ErstellerNR` int(11) NOT NULL,
  `AufgabenNR` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Aufgabenliste`
--

INSERT INTO `Aufgabenliste` (`AufgabenlisteNR`, `ErstellerNR`, `AufgabenNR`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `Ersteller`
--

CREATE TABLE `Ersteller` (
  `ErstellerNR` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Vorname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `Ersteller`
--

INSERT INTO `Ersteller` (`ErstellerNR`, `Name`, `Vorname`) VALUES
(1, 'Daniel', 'Brites');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `Aufgabe`
--
ALTER TABLE `Aufgabe`
  ADD PRIMARY KEY (`AufgabeNR`);

--
-- Indizes für die Tabelle `Aufgabenliste`
--
ALTER TABLE `Aufgabenliste`
  ADD PRIMARY KEY (`AufgabenlisteNR`,`ErstellerNR`);

--
-- Indizes für die Tabelle `Ersteller`
--
ALTER TABLE `Ersteller`
  ADD PRIMARY KEY (`ErstellerNR`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
