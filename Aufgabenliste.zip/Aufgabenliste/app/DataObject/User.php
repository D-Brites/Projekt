<?php declare(strict_types=1);

namespace App\DataObject;

class User
{
    private $id;

    private $name;

    private $vorname;

    /**
     * User constructor.
     * @param $id
     * @param $vorname
     * @param $name
     */
    public function __construct($id, $vorname, $name)
    {
        $this->id = $id;
        $this->vorname = $vorname;
        $this->name = $name;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function getvorname()
    {
        return $this->vorname;
    }

    /**
     * @return mixed
     */
    public function getName()
    {
        return $this->name;
    }

}