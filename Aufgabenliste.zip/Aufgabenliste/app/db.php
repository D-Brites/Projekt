<?php

require 'rb.php';
define( 'REDBEAN_MODEL_PREFIX', '' );
R::setup('mysql:host=localhost;dbname=danielbrites1_aufgabenliste', 'danielbrites1_root', '123');