<?php

use Psr\Container\ContainerInterface;
use Slim\Factory\AppFactory;
use Slim\Views\PhpRenderer;

require '../vendor/autoload.php';

require  '../app/db.php';

session_start();

$container = new \DI\Container();
AppFactory::setContainer($container);
$app =  AppFactory::create();


$app->addBodyParsingMiddleware();

$app->addRoutingMiddleware();

$app->getContainer()->set('LoginController', function(ContainerInterface $c) {
   return new \App\Controller\LoginController($c);
});

$app->getContainer()->set('TaskListController', function(ContainerInterface $c) {
    return new \App\Controller\api\TaskListController($c);
});

$app->getContainer()->set('TaskController', function(ContainerInterface $c) {
    return new \App\Controller\api\TaskController($c);
});

$app->add(new \Tuupola\Middleware\JwtAuthentication([
    'path' => '/backend/api',
    'secret' => 'ZRkVFu1myrXKfSwfB5azO5fKoV8GD5vq',
    'attribute' => 'token_data'
]));

require '../app/routes.php';

