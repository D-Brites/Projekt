<?php

namespace App\Model;

/**
 * Class User
 * @package App\Model
 */
class Model_User extends \RedBean_SimpleModel
{

}