<?php

namespace App\Model;

/**
 * Class AufgabenListe
 * @package App\Model
 */
class AufgabenListe extends \RedBean_SimpleModel
{

}