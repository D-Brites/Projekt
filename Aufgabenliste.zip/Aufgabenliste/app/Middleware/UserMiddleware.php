<?php declare(strict_types=1);

namespace App\Middleware;

use App\DataObject\User;
use DI\Container;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use R;
use Slim\Exception\HttpUnauthorizedException;

class UserMiddleware implements MiddlewareInterface
{
    /**
     * @var Container $container
     */
    private $container;

    /**
     * UserMiddleware constructor.
     * @param Container $container
     */
    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * @inheritDoc
     * @throws HttpUnauthorizedException
     */
    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $tokenData = $request->getAttribute('token_data');
        $erstellerDb = R::findOne('ersteller', 'id=?', [$tokenData['id']]);

        if (!$erstellerDb) {
            throw new HttpUnauthorizedException($request);
        }
        $ersteller = new User($tokenData['id'], $tokenData['vorname'], $tokenData['name']);

        $this->container->set('ersteller', $ersteller);

        return $handler->handle($request);
    }
}