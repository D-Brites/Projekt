<?php declare(strict_types=1);

namespace App\Controller;

use Psr\Container\ContainerInterface;
use Slim\Psr7\Response;

abstract class BasicController
{
    /**
     * @var ContainerInterface
     */
    protected $container;

    /**
     * BasicController constructor.
     * @param ContainerInterface $container
     */
    public function __construct(ContainerInterface $container)
    {
        $this->container = $container;
    }

    /**
     * @return ContainerInterface
     */
    public function getContainer(): ContainerInterface
    {
        return $this->container;
    }

    /**
     * @param Response $response
     * @param int $statusCode
     * @param $data
     * @return Response
     */
    protected function createApiResponse(Response $response, $data, int $statusCode = 200): Response
    {
        $payload = json_encode($data);
        $response->getBody()->write($payload);
        
        return $response->withHeader('Content-Type', 'application/json')->withStatus($statusCode);
    }
}
