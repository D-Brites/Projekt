import { Component, OnInit, HostListener, Input } from '@angular/core';
import { SplitInterpolation } from '@angular/compiler';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {
  //variablen die benötigt werden --------------------------------------------------------
  beschValue: string;
  newListName: string;
  tableid: number;
  newTaskGewicht: string;
  newTaskList: string;
  newTaskFrist: string;
  newTaskTitel: string;
  newTaskStatus: string;

  changeListName: string;
  changeListArray = [];
  changeTaskNumber: string;
  changeTaskArray = [];
  changeBesch: string;
  changeFrist: Date;
  changeGewicht: string;
  changeTitel: string;

  saveChangedBesch: string;
  saveChangedFrist: string;
  saveChangedGewicht: string;
  saveChangedStatus: string;
  saveChangedTitel: string;
  saveChnagedStatus: string;

  deleteListName: string;

  taskChecked: boolean;
  id: string;
  rowId: string;
  //----------------------------------------------------------------------------------------
  yourData = [ //array mit den Daten
    {
      list: [
        {
          id: "1",
          name: "essen"
        }
      ],
      columns: [
        {
          heading: "Nummer",
          field: "nummer"
        },
        {
          heading: "Titel",
          field: "titel"
        },
        {
          heading: "Beschreibung",
          field: "beschreibung"
        },
        {
          heading: "Frist",
          field: "frist"
        },
        {
          heading: "Status",
          field: "status"
        },
        {
          heading: "Gewicht",
          field: "gewicht"
        }
      ],
      data: [
        {
          nummer: "1",
          titel: "Essen machen",
          beschreibung: "Für Freunde kochen",
          frist: "2020-01-01",
          status: "offen",
          gewicht: "4"
        }
      ]
    },
    {
      list: [
        {
          id: "2",
          name: "Einkaufen"
        }
      ],
      columns: [
        {
          heading: "Nummer",
          field: "nummer"
        },
        {
          heading: "Titel",
          field: "titel"
        },
        {
          heading: "Beschreibung",
          field: "beschreibung"
        },
        {
          heading: "Frist",
          field: "frist"
        },
        {
          heading: "Status",
          field: "status"
        },
        {
          heading: "Gewicht",
          field: "gewicht"
        }
      ],
      data: [
        {
          nummer: "1",
          titel: "Zitronen",
          beschreibung: "Zitronen",
          frist: "2020-01-01",
          status: "offen",
          gewicht: "3"
        },
        {
          nummer: "2",
          titel: "Toast",
          beschreibung: "Vollkorn Toast von Rewe",
          frist: "2020-01-01",
          status: "offen",
          gewicht: "1"
        }
      ]
    }
  ];

  constructor() { }
  @Input('sortable-column')
  columnName: string;

  @Input('sort-direction')
  sortDirection: string = '';

  @HostListener('click')
  sort() {
    this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
  }
  computeData(column, row) { //für die dynamischen Tabellen
    var mappedDataRow = [];
    column.forEach(columnElement => {
      mappedDataRow.push(row[columnElement.field]);
    });
    return mappedDataRow;
  }
  createNewList() { //neue Liste erstellen
    this.tableid = this.yourData.length + 1;
    this.yourData.push({
      list: [
        {
          id: this.tableid.toString(),
          name: this.newListName
        }
      ],
      columns: [ //muss angegeben sein...
        {
          heading: "Nummer",
          field: "nummer"
        },
        {
          heading: "Titel",
          field: "titel"
        },
        {
          heading: "Beschreibung",
          field: "beschreibung"
        },
        {
          heading: "Frist",
          field: "frist"
        },
        {
          heading: "Status",
          field: "status"
        },
        {
          heading: "Gewicht",
          field: "gewicht"
        }
      ],
      data: [ //leer da keine Daten rein sollen

      ]
    })
  }

  addToTable() { //eintrag zu Aufgabenliste hinzufügen
    for (var i = 0; i < this.yourData.length; i++) {
      if (this.yourData[i].list[0].name == this.newTaskList) {//richtige Liste finden
        var newNumber = this.yourData[i].data.length + 1;
        this.yourData[i].data.push({ //daten einfügen
          nummer: newNumber.toString(),
          beschreibung: this.beschValue,
          frist: this.newTaskFrist,
          gewicht: this.newTaskGewicht,
          status: this.newTaskStatus,
          titel: this.newTaskTitel
        });
      }
    }
  }

  listSelected() {//aufgaben der liste auflisten
    this.changeListArray = [];
    for (var i = 0; i < this.yourData.length; i++) {
      if (this.yourData[i].list[0].name == this.changeListName) {
        for (var j = 0; j < this.yourData[i].data.length; j++) {
          this.changeListArray.push(this.yourData[i].data[j].nummer);
        }
      }
    }
  }

  taskSelected() {
    this.changeTaskArray = [];
    for (var i = 0; i < this.yourData.length; i++) {
      for (var j = 0; j < this.yourData[i].data.length; j++) {//sucht die Aufgabe
        if (this.yourData[i].data[j].nummer == this.changeTaskNumber && this.yourData[i].list[0].name == this.changeListName) {//check auf richtige Liste
          this.changeTaskArray.push(this.yourData[i].data[j]); //aktuelle Daten laden und ein array schreiben
          this.changeBesch = this.changeTaskArray[0].beschreibung; //felder vorbefüllen
          this.changeFrist = this.changeTaskArray[0].frist;
          this.changeGewicht = this.changeTaskArray[0].gewicht;
          this.changeTitel = this.changeTaskArray[0].titel;

          this.saveChangedBesch = this.changeTaskArray[0].beschreibung; //fals keine änderung: vorher auf alter wert
          this.saveChangedFrist = this.changeFrist = this.changeTaskArray[0].frist;;
          this.saveChangedGewicht = this.changeGewicht = this.changeTaskArray[0].gewicht;
          this.saveChangedTitel = this.changeTaskArray[0].titel;
        }
      }
    }
  }

  saveChanges() { //speichert die änderungen an einer Aufgabe
    this.changeTaskArray = [];
    for (var i = 0; i < this.yourData.length; i++) {  //for-schleifen suchen die Aufgabe
      for (var j = 0; j < this.yourData[i].data.length; j++) {
        if (this.yourData[i].data[j].nummer == this.changeTaskNumber && this.yourData[i].list[0].name == this.changeListName) { //check auf die richtige Liste
          this.yourData[i].data[j] = ({ //neue Daten einsetzen
            nummer: this.changeTaskNumber,
            beschreibung: this.saveChangedBesch,
            frist: this.saveChangedFrist,
            gewicht: this.saveChangedGewicht,
            status: this.saveChangedStatus,
            titel: this.saveChangedTitel
          });
        }
      }
    }
  }

  deleteList(id) { //löscht eine Liste
    for (var i = 0; i < this.yourData.length; i++) {
      if (this.yourData[i].list[0].name == this.deleteListName) {
        this.yourData.splice(i, 1);
      }
    }
  }

  taskCheckChange() {
    this.taskChecked != this.taskChecked;
    console.log("done ");
    //leider kein Highliting der zeile geschafft...
  }

  ngOnInit(): void {

  }

}
